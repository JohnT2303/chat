export interface UserDetails {
  name: string;
  id: string;
}
