export interface Message {
  from?: string;
  to: string;
  message: string;
  date: Date;
}
